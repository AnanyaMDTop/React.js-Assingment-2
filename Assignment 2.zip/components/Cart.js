import React from 'react';

function Cart({ cartItems }) {
  return (
    <div>
      <h1 align='center' style={{fontweight:700,backgroundColor:'pink'}}>Your Cart</h1>
      {cartItems.length === 0 ? (
        <p align='center'>Your cart is empty.</p>
      ) : (
        <ul>
          {cartItems.map((item, index) => (
            <li key={index}>{item.name} - {item.price} Rs</li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Cart;




import React from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom for navigation

function Navbar() {
  return (
    <nav style={{ backgroundColor: '#ff7f50', padding: '10px' }}>
      <ul style={{ listStyle: 'none', display: 'flex', justifyContent: 'space-around' }}>
        <li><Link to="/" style={{ color: 'white', textDecoration: 'none',fontWeight:700, fontSize:20}}>Home</Link></li>
        <li><Link to="/Cakes" style={{ color: 'white', textDecoration: 'none',fontWeight:700, fontSize:20 }}>Cakes</Link></li>
        <li><Link to="/Cart" style={{ color: 'white', textDecoration: 'none',fontWeight:700, fontSize:20 }}>Cart</Link></li>
      </ul>
    </nav>
    
  );
}

export default Navbar;

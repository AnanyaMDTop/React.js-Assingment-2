import React from 'react';
import CakeList from './CakeList'; // Import the CakeList component

function Cakes({ cakes, onAddToCart }) {
  return (
    <div>
      <h2 align='center' style={{backgroundColor:'pink'}}>Available Cakes</h2>
      <CakeList cakes={cakes} onAddToCart={onAddToCart} />
    </div>
  );
}

export default Cakes;

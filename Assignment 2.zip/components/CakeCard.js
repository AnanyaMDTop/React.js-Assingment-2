// src/components/CakeCard.js

import React from 'react';

const CakeCard = ({ cake, addToCart }) => {
  return (
    <div className="container">
    <div className="cake-card">
    <img src={cake.image} alt={cake.name} className="cake-img" />
    <h2 style={{ color:'black', textDecoration: 'none',fontWeight:700, fontSize:40}} >{cake.name}</h2>
    <p style={{fontSize:30}}>${cake.price}</p>
    <p style={{fontSize:20}}>{cake.description}</p>
    <button onClick={() => addToCart(cake)} style={{fontWeight:700}}>Add to Cart</button>
  </div>
  </div>
    
  );
};

export default CakeCard;

import React from 'react';

function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '20px' }}>
      <h1>Welcome to Our Cake Shop!</h1>
      <h2> Select your favorite cakes in the cakes section.</h2>
      <h3 align="center"><a href="aboutus.html">About Us</a></h3>
      <footer style={{backgroundColor:'pink',fontWeight:700}}>
        <p>&copy; 2023 Cake Shop.All rights reserved.</p>
        </footer>
        
    </div>
  );
}

export default Home;

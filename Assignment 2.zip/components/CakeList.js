// src/components/CakeList.js
import React, { useEffect, useState } from 'react';
import CakeCard from './CakeCard';

function CakeList() {
  const [cakes, setCakes] = useState([]);

  useEffect(() => {
    // Fetch cakes data from an API or hardcoded data for now
    const fetchData = async () => {
      const cakeData = [
        { id: 1, name: 'Chocolate Cake', price: 20,image:"https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcTlb4W-snjYw1d_U1Yd3xTWArk6tXJS9jVdBaN17GyhbSBdl97jGIqbb7uDXN7vhhI-st336l9O9PF9eqnBooCA21RpZXfLovtq3hZtDks " ,description:'Fully cream   500gm    Shape:Heart shaped'},
        { id: 2, name: 'Vanilla Cake', price: 18, image:"https://imgcdn.floweraura.com/scrumptious-vanilla-cake-9993570ca-AAA.jpg?tr=w-266,dpr-1.5,q-70 " ,description:'Flavor:Vanilla   Cake Shape: Round     Type: Cream  500gms'},
        { id: 3, name: 'Red velvet',price:22, image:"https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcS90sdHHZoMMDIgvfwCytuM8Ub84YKZWHlieu6ld9-LhOV4IMWDdzAmovxSi0Hs-P6dW9dsEE5joRmSl3bNULThYnXAksng ",description:'Cake Flavour- Red Velvet   Type of Cake - Cream    Shape- Round    Weight: 500 gm     Net Quantity: 1 Cake    Diameter: 7.5 inch    Country Of Origin: India    Serves: 4-6 People' }
      ];
      setCakes(cakeData);
    };

    fetchData();
  }, []);

  return (
    <div className="cake-list">
      {cakes.map((cake) => (
        <CakeCard key={cake.id} cake={cake} />
      ))}
    </div>
  );
}

export default CakeList;
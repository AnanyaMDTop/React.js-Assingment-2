import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Import Router and Routes
import Navbar from './components/Navbar';
import Home from './components/Home';
import Cakes from './components/Cakes';
import Cart from './components/Cart';
import './styles/styles.css';

function App() {
  const [cartItems, setCartItems] = useState([]);

  const cakes = [
    { name: 'Chocolate Cake', price: 15, image: 'chocolate-cake.jpg' },
    { name: 'Vanilla Cake', price: 12, image: 'vanilla-cake.jpg' },
    { name: 'Strawberry Cake', price: 14, image: 'strawberry-cake.jpg' }
  ];

  const handleAddToCart = (cake) => {
    setCartItems([...cartItems, cake]);
  };

  return (
    <Router>
      <Navbar />
      <div style={{ padding: '20px' }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cakes" element={<Cakes cakes={cakes} onAddToCart={handleAddToCart} />} />
          <Route path="/cart" element={<Cart cartItems={cartItems} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
